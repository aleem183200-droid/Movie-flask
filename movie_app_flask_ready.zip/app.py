from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = "supersecret"

# Home page
@app.route("/")
def home():
    return render_template("index.html")

# Login page
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        role = request.form.get("role")
        password = request.form.get("password")

        if role == "admin" and password == "607094Ss@":
            session["user"] = "admin"
            return redirect(url_for("admin"))
        elif role == "user":
            session["user"] = "user"
            return redirect(url_for("home"))
        else:
            return "Invalid credentials!"
    return render_template("login.html")

# Admin panel
@app.route("/admin")
def admin():
    if "user" in session and session["user"] == "admin":
        return render_template("admin.html")
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(debug=True)
